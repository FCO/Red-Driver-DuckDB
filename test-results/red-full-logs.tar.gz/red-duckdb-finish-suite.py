from pathlib import Path
import concurrent.futures
import subprocess
import json
root = Path('/Users/fernando/Projects/Red')
results = Path('/tmp/red-duckdb-full-results')
missing = [p for p in sorted((root/'t').rglob('*.rakutest')) if not (results/(p.name+'.json')).exists()]
print('Remaining files:', len(missing), flush=True)
def run(path):
    result = subprocess.run(['python3', '/tmp/red-duckdb-test-exec.py', str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
    return path.name, result.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    for name, code in pool.map(run, missing):
        print(name, 'exit', code, flush=True)
