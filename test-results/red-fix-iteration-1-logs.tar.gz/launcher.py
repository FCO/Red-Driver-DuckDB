import json
import pathlib
import subprocess
import sys
import time
start = time.monotonic()
root = pathlib.Path('/tmp/red-duckdb-fix-results')
root.mkdir(exist_ok=True)
test_path = pathlib.Path(sys.argv[-1]).resolve()
name = test_path.name
arguments = sys.argv[1:-1] + [str(test_path)]
test_cwd = '/Users/fernando/Projects/Red' if '/Projects/Red/t/' in str(test_path) else None
try:
    completed = subprocess.run([
        '/Users/fernando/.rakubrew/versions/moar-main/install/bin/raku',
        '-I/Users/fernando/Projects/Red/lib',
        '-I/Users/fernando/Projects/Red-Driver-DuckDB/lib',
        '-MRed::Driver::DuckDB', *arguments
    ], cwd=test_cwd, timeout=180, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = completed.stdout
    code = completed.returncode
except subprocess.TimeoutExpired as error:
    output = (error.stdout or b'') + b'\nBail out! Per-file timeout after 180 seconds\n'
    code = 124
(root / (name + '.log')).write_bytes(output)
(root / (name + '.json')).write_text(json.dumps({'file': sys.argv[-1], 'exit_code': code, 'seconds': round(time.monotonic()-start, 2)}))
sys.stdout.buffer.write(output.replace(b'Bail out!', b'# Original Bail out!'))
sys.stdout.buffer.flush()
sys.exit(code)
