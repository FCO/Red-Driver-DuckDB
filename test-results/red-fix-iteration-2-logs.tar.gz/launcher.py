#!/usr/bin/env python3
"""prove6 launcher: preload DuckDB and keep diagnostic stderr out of TAP stdout.

RED_CHECKOUT overrides the sibling Red checkout. RED_TEST_RESULTS chooses the
artifact directory; RED_TEST_TIMEOUT defaults to 180 seconds per file.
"""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

project = Path(__file__).resolve().parent.parent
red = Path(os.environ.get('RED_CHECKOUT', str(project.parent / 'Red'))).resolve()
results = Path(os.environ.get('RED_TEST_RESULTS', str(project / 'test-results' / 'latest')))
results.mkdir(parents=True, exist_ok=True)
test = Path(sys.argv[-1]).resolve()
command = [shutil.which('raku') or 'raku', f'-I{red / "lib"}',
           f'-I{project / "lib"}', '-MRed::Driver::DuckDB', *sys.argv[1:-1], str(test)]
started = time.monotonic()
cwd = red if test.is_relative_to(red / 't') else project
stdout = stderr = b''
try:
    completed = subprocess.run(command, cwd=cwd, timeout=float(os.environ.get('RED_TEST_TIMEOUT', '180')),
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr, code = completed.stdout, completed.stderr, completed.returncode
except subprocess.TimeoutExpired as error:
    stdout = (error.stdout or b'') + b'\nBail out! Per-file timeout\n'
    stderr = error.stderr or b''
    code = 124
prefix = results / test.name
Path(str(prefix) + '.tap').write_bytes(stdout)
Path(str(prefix) + '.stderr.log').write_bytes(stderr)
Path(str(prefix) + '.log').write_bytes(stdout + (b'\n[stderr]\n' + stderr if stderr else b''))
Path(str(prefix) + '.json').write_text(json.dumps({
    'file': str(test), 'driver': os.environ.get('RED_DATABASE'),
    'exit_code': code, 'seconds': round(time.monotonic() - started, 2), 'command': command,
}, indent=2) + '\n')
# A failed file must not prevent the harness from invoking every remaining file.
# The original Bail out! remains in its .tap artifact and its nonzero exit status.
sys.stdout.buffer.write(stdout.replace(b'Bail out!', b'# Original Bail out!'))
sys.stdout.buffer.flush()
sys.stderr.buffer.write(stderr)
sys.stderr.buffer.flush()
sys.exit(code)
