import json
import pathlib
import subprocess
import sys
import time
start = time.monotonic()
root = pathlib.Path('/tmp/red-duckdb-full-results')
root.mkdir(exist_ok=True)
name = pathlib.Path(sys.argv[-1]).name
try:
    completed = subprocess.run([
        '/Users/fernando/.rakubrew/versions/moar-main/install/bin/raku',
        '-I/Users/fernando/Projects/Red/lib',
        '-I/Users/fernando/Projects/Red-Driver-DuckDB/lib',
        '-MRed::Driver::DuckDB', *sys.argv[1:]
    ], timeout=180, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = completed.stdout
    code = completed.returncode
except subprocess.TimeoutExpired as error:
    output = (error.stdout or b'') + b'\nBail out! Per-file timeout after 180 seconds\n'
    code = 124
(root / (name + '.log')).write_bytes(output)
(root / (name + '.json')).write_text(json.dumps({'file': sys.argv[-1], 'exit_code': code, 'seconds': round(time.monotonic()-start, 2)}))
sys.stdout.buffer.write(output)
sys.stdout.buffer.flush()
sys.exit(code)
